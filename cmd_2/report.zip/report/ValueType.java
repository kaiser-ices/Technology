package report;

public enum ValueType {
	VOID,
	INTEGER,
	STRING,
	DOUBLE,
	BOOL,
}

