package report;

import java.io.File;

public class Main {

	/**
	 * 実行ファイル
	 */
	private static final String SORCE_PATH = "test.txt";

	public static void main(String[] args) {
		try {
			LexicalAnalyzer lex;
			LexicalUnit first;
			Environment env;
			Node program;

			if (new File(SORCE_PATH).exists() == false) {
				System.out.println("nothing");
				return;
			}

			lex = new LexicalAnalyzerImpl(SORCE_PATH);
			env = new Environment(lex);
			first = lex.get();
			lex.unget(first);

			program = ProgramNode.isMatch(env, first);
			boolean res = program.parse();
			if (res == false) {
				System.out.println("Syntax error");
				return;
			}
			// 構文木表示
			System.out.println("Syntax parsed ---");
			System.out.println(program);
			System.out.println("-----------------");

			System.out.println("-------run!------");
			// プログラム実行
			program.eval();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}

