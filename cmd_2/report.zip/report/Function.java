package report;

public abstract class Function {
	public abstract Value eval(ExprListNode arg);
}

